import type { AppSettings, ExtractedItem, NormalizedMessage } from "@/types";
import { DB_NAME, DB_VERSION, DEFAULT_SETTINGS, STORE_ITEMS, STORE_KEY, STORE_MESSAGES, STORE_SETTINGS } from "@/config";

let dbPromise: Promise<IDBDatabase> | null = null;

/** Open one shared IndexedDB connection and recover cleanly after schema changes. */
function openDB(): Promise<IDBDatabase> {
  if (typeof indexedDB === "undefined") {
    return Promise.reject(new Error("Local storage is unavailable in this browser context."));
  }
  if (dbPromise) return dbPromise;

  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_MESSAGES)) db.createObjectStore(STORE_MESSAGES, { keyPath: "id" });
      if (!db.objectStoreNames.contains(STORE_ITEMS)) db.createObjectStore(STORE_ITEMS, { keyPath: "id" });
      if (!db.objectStoreNames.contains(STORE_SETTINGS)) db.createObjectStore(STORE_SETTINGS);
    };
    req.onsuccess = () => {
      const db = req.result;
      db.onversionchange = () => {
        db.close();
        dbPromise = null;
      };
      resolve(db);
    };
    req.onerror = () => {
      dbPromise = null;
      reject(req.error ?? new Error("Could not open local database."));
    };
    req.onblocked = () => {
      // A blocked upgrade cannot complete until another tab closes its old connection.
      dbPromise = null;
      reject(new Error("Database upgrade is blocked by another open tab. Close other tabs and retry."));
    };
  });
  return dbPromise;
}

function runTransaction<T>(
  stores: string | string[],
  mode: IDBTransactionMode,
  action: (tx: IDBTransaction) => IDBRequest<T> | void,
): Promise<T | undefined> {
  return openDB().then((db) => new Promise<T | undefined>((resolve, reject) => {
    let result: T | undefined;
    let settled = false;
    let tx: IDBTransaction;
    try {
      tx = db.transaction(stores, mode);
      const request = action(tx);
      if (request) {
        request.onsuccess = () => { result = request.result; };
        request.onerror = () => { /* transaction.onerror provides the final failure */ };
      }
    } catch (error) {
      reject(error);
      return;
    }
    tx.oncomplete = () => { settled = true; resolve(result); };
    tx.onerror = () => {
      if (!settled) reject(tx.error ?? new Error("Database transaction failed."));
    };
    tx.onabort = () => {
      if (!settled) reject(tx.error ?? new Error("Database transaction was aborted."));
    };
  }));
}

async function replaceAll<T extends { id: string }>(storeName: string, records: T[]): Promise<void> {
  await runTransaction(storeName, "readwrite", (tx) => {
    const store = tx.objectStore(storeName);
    store.clear();
    for (const record of records) store.put(record);
  });
}

async function readAll<T>(storeName: string): Promise<T[]> {
  const records = await runTransaction<T[]>(storeName, "readonly", (tx) => tx.objectStore(storeName).getAll());
  return records ?? [];
}

export async function saveMessages(messages: NormalizedMessage[]): Promise<void> {
  await replaceAll(STORE_MESSAGES, messages);
}

export function loadMessages(): Promise<NormalizedMessage[]> {
  return readAll<NormalizedMessage>(STORE_MESSAGES);
}

export async function saveItems(items: ExtractedItem[]): Promise<void> {
  await replaceAll(STORE_ITEMS, items);
}

export function loadItems(): Promise<ExtractedItem[]> {
  return readAll<ExtractedItem>(STORE_ITEMS);
}

export async function saveSettings(settings: AppSettings): Promise<void> {
  await runTransaction(STORE_SETTINGS, "readwrite", (tx) =>
    tx.objectStore(STORE_SETTINGS).put(settings, STORE_KEY),
  );
}

export async function loadSettings(): Promise<AppSettings> {
  const settings = await runTransaction<AppSettings>(STORE_SETTINGS, "readonly", (tx) =>
    tx.objectStore(STORE_SETTINGS).get(STORE_KEY),
  );
  return settings ?? { ...DEFAULT_SETTINGS, weights: { ...DEFAULT_SETTINGS.weights } };
}

export async function deleteAllData(): Promise<void> {
  await runTransaction([STORE_MESSAGES, STORE_ITEMS, STORE_SETTINGS], "readwrite", (tx) => {
    tx.objectStore(STORE_MESSAGES).clear();
    tx.objectStore(STORE_ITEMS).clear();
    tx.objectStore(STORE_SETTINGS).clear();
  });
}
