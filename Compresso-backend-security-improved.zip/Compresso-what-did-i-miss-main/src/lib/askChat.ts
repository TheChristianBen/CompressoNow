import type { ChatAnswer, NormalizedMessage } from "@/types";

function tokenize(text: string): Set<string> {
  return new Set(text
    .toLowerCase()
    .replace(/[^\w\s]/g, " ")
    .split(/\s+/)
    .filter((token) => token.length > 2));
}

function scoreMessage(queryTokens: Set<string>, hasQuestionMark: boolean, message: NormalizedMessage): number {
  if (queryTokens.size === 0) return 0;
  const messageTokens = tokenize(message.text);
  const senderTokens = tokenize(message.sender);
  let score = 0;

  for (const queryToken of queryTokens) {
    if (messageTokens.has(queryToken)) score += 2;
    else {
      // Keep partial-word matching, but avoid scanning the message tokens twice.
      for (const messageToken of messageTokens) {
        if (messageToken.includes(queryToken) || queryToken.includes(messageToken)) {
          score += 1;
          break;
        }
      }
    }
    if (senderTokens.has(queryToken)) score += 1;
  }

  if (hasQuestionMark && message.text.includes("?")) score += 1;
  return score;
}

export function askChat(question: string, messages: NormalizedMessage[]): ChatAnswer {
  if (!question.trim()) {
    return { text: "Please enter a question.", sourceMessageIds: [], found: false };
  }

  const queryTokens = tokenize(question);
  const hasQuestionMark = question.includes("?");
  const scored = messages
    .map((message) => ({ message, score: scoreMessage(queryTokens, hasQuestionMark, message) }))
    .filter((entry) => entry.score > 0)
    .sort((a, b) => b.score - a.score);

  if (scored.length === 0) {
    return { text: "Not found in this chat.", sourceMessageIds: [], found: false };
  }

  const topMessages = scored.slice(0, 5).map((entry) => entry.message);
  const summary = topMessages.map((message) => `${message.sender}: "${message.text}"`).join("\n\n");

  return {
    text: `Based on the chat, here's what I found:\n\n${summary}`,
    sourceMessageIds: topMessages.map((message) => message.id),
    found: true,
  };
}
